Project Reference: All

###This code will:###
	Deploy a given file to all servers listed in the PROSHFASDB1.ApplicationServices.dbo.tblMDServers to the destination path described by $Destpath 
	
###Deployment steps:###
	Step 1) Modify powershell to change destination path.
	Step 2) Run powershell.
	Step 3) Select file

### Who do I talk to? ###
	Submitted by: Aidan Fennessy