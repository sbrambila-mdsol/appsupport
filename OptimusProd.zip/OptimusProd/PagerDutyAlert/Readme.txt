1. Install all procedures in SP folder.
2. Install the job from the JOB folder.
